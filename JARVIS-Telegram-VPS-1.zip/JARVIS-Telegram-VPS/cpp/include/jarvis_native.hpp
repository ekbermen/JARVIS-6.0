#pragma once
#include <string>
namespace jarvis_native { std::string normalize_command(const std::string& input); std::string version(); }
