#include "jarvis_native.hpp"
#include <algorithm>
#include <cctype>
namespace jarvis_native {
std::string normalize_command(const std::string& input){ std::string out=input; std::transform(out.begin(),out.end(),out.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));}); return out; }
std::string version(){ return "jarvis-native-1.0"; }
}
