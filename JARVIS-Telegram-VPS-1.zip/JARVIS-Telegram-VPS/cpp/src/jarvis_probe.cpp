#include "jarvis_native.hpp"
#include <iostream>
int main(){std::string line;std::getline(std::cin,line);std::cout<<jarvis_native::normalize_command(line)<<"\n";std::cerr<<jarvis_native::version()<<"\n";}
