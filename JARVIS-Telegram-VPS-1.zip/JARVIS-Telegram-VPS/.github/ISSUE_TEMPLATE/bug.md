---
name: Bug report
about: JARVIS hatası
---

## Belirti

## Son log

## Beklenen davranış

## Gerçek davranış
