## Feature
Describe the agent capability, required permissions, risk level and acceptance criteria.
