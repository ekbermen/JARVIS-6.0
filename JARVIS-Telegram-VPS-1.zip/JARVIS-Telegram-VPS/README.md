# JARVIS 6.0 — Telegram + Grok/xAI + VPS

Bu repo, Telegram üzerinden özel kullanımlı bir JARVIS kurmak için genişletilebilir bir temel sunar. Ana çalışma zamanı Node.js'tir. Python ve C++ klasörleri ağır işlemler / gelecekteki modüller için ayrılmıştır; bu diller ana botu gereksiz yere bağımlı hale getirmez.

## Ana akış

`Telegram voice -> getFile -> xAI Speech-to-Text -> Grok chat -> xAI Text-to-Speech -> Telegram sendVoice`

Metin üretimi ile ses üretimi bilerek iki ayrı aşamadır. Böylece cevabın tam metnini kaydetmek, filtrelemek, uzunluğu kontrol etmek ve tekrar üretmek mümkündür.

## Önemli güvenlik

Bot yalnızca `ALLOWED_TELEGRAM_USER_ID` ve/veya `ALLOWED_TELEGRAM_CHAT_ID` eşleşen istekleri işler. API anahtarları kaynak koduna yazılmaz; VPS'te environment variable olarak tutulur.

## Repo yapısı

```text
JARVIS-Telegram-VPS/
├── public/                 # Web paneli (index.html)
├── src/                    # VPS botu
│   ├── ai/                 # Grok/xAI chat, STT, TTS
│   ├── audio/              # Ses dosyası kontrolü / geçici dosyalar
│   ├── commands/           # Telegram komutları
│   ├── config/             # Ortam değişkenleri ve doğrulama
│   ├── health/             # Health/status
│   ├── memory/             # Konuşma hafızası
│   ├── security/           # Yetkilendirme, webhook doğrulama
│   ├── telegram/           # Telegram Bot API istemcisi
│   └── utils/              # Genel yardımcılar
├── python/                 # Opsiyonel Python yardımcı servisleri
├── cpp/                    # Opsiyonel C++ hızlı yardımcı modülleri
├── deploy/                 # systemd, nginx, Docker
├── scripts/                # kurulum, webhook, health
└── tests/                  # temel testler
```

## Kurulum — VPS

1. Ubuntu 24.04+ önerilir.
2. Node.js 20+ kur.
3. `npm install` çalıştır.
4. `.env.example` dosyasını `.env` olarak kopyala.
5. Telegram bot token ve xAI API anahtarını gir.
6. `npm start` ile başlat.
7. Nginx + HTTPS kullan.
8. `PUBLIC_BASE_URL` ile webhook URL'sini ayarla.
9. `npm run setup:webhook` çalıştır.
10. systemd servisini etkinleştir.

## Netlify

`public/index.html` görüntüleme paneli için kullanılabilir. Ancak Telegram token, xAI anahtarı gibi sırlar tarayıcı tarafına konmaz. Botun 7/24 çalışması için VPS servisi esas çalışma katmanıdır.

Netlify sadece panel/web katmanı olarak kullanılabilir.

## Grok/xAI hatalarını ayıklama

`src/ai/xai-client.js` tüm xAI çağrılarını ortak timeout/retry/hata ayrıştırması ile yapar. `XAI_CHAT_MODEL` yanlışsa gelen API hatası loglanır; servis 500 döndürmek yerine kontrollü hata üretir. STT/TTS cevabında beklenen alanlar yoksa da açık hata alınır.

## Not

xAI API model isimleri zaman içinde değişebilir. Model adı environment variable üzerinden verildiği için kodu değiştirmeden güncelleyebilirsin.
