# Mimari kararlar

## Neden Node.js ana servis?

Telegram HTTP API, webhook ve xAI REST çağrıları I/O ağırlıklıdır. Tek bir Node.js servisinin kurulumu kolay ve VPS kaynak ihtiyacı düşüktür.

## Python neden opsiyonel?

Python audio/ML araçları açısından geniş ekosisteme sahiptir. Ama botun temel zincirini Python'a bağlamak deployment karmaşıklığını artırır. Ağır iş gerekirse ayrı servis olarak açılır.

## C++ neden opsiyonel?

C++ düşük seviyeli ve yüksek performanslı yardımcılar için tutulur. Telegram API çağrısı yapmak için C++ kullanmak gereksizdir.

## Veri akışı

1. Telegram webhook update gelir.
2. Allowlist kontrolü yapılır.
3. Voice varsa `getFile` ile dosya yolu alınır.
4. Ses xAI STT'ye gider.
5. Transcript konuşma hafızasına eklenir.
6. Grok transcript + kısa geçmiş ile cevap üretir.
7. Cevap hafızaya yazılır.
8. Cevap xAI TTS ile MP3'e dönüştürülür.
9. Telegram `sendVoice` ile geri gönderir.

## Hata stratejisi

xAI istemcisi timeout + exponential backoff uygular. Telegram işlemleri de kontrollü retry kullanır. İşlem zinciri kırılırsa hata runtime durumuna yazılır.
