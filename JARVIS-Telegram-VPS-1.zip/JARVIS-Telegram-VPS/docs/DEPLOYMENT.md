# VPS dağıtımı

```bash
sudo bash scripts/install-vps.sh
sudo useradd --system --create-home jarvis || true
sudo mkdir -p /opt/jarvis
sudo chown -R jarvis:jarvis /opt/jarvis
```

Repo'yu `/opt/jarvis` altına koy:

```bash
cd /opt/jarvis
cp .env.example .env
nano .env
npm install
```

systemd:

```bash
sudo cp deploy/systemd/jarvis.service /etc/systemd/system/jarvis.service
sudo systemctl daemon-reload
sudo systemctl enable --now jarvis
sudo systemctl status jarvis
```

Nginx:

```bash
sudo cp deploy/nginx/jarvis.conf /etc/nginx/sites-available/jarvis
sudo ln -s /etc/nginx/sites-available/jarvis /etc/nginx/sites-enabled/jarvis
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d jarvis.example.com
```

Sonra:

```bash
npm run setup:webhook
```
