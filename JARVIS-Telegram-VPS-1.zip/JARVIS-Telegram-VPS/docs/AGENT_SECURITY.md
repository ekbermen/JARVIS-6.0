# Agent security

Default-deny for shell/device-control tools. Use an approval gate, sandboxed execution, path allowlists, rate limits, audit logs and secret isolation.
