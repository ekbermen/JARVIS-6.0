# Güvenlik

- `.env` Git'e gönderilmez.
- Telegram kullanıcı/chat allowlist'i zorunlu hale getirilebilir.
- Webhook için Telegram secret token kullanılabilir.
- Nginx arkasında HTTPS kullanılmalıdır.
- Admin test endpoint'i `ADMIN_TOKEN` ile korunabilir.
- Loglara API anahtarı yazılmamalıdır.
- `PUBLIC_BASE_URL` yalnızca URL bilgisidir; sır değildir.
- `data/conversations.json` hassas konuşma içerebilir. Sunucuda dosya izinlerini kısıtla.
