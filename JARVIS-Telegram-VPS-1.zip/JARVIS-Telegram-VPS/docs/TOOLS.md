# JARVIS Tools

Planned tools: filesystem, sandboxed shell, web research, GitHub, scheduler, Telegram, Android companion, code runner, media, database, monitoring.
