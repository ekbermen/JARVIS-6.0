# Roadmap

Phase 1: Telegram voice pipeline.
Phase 2: tools + approvals.
Phase 3: Android companion.
Phase 4: memory/RAG.
Phase 5: multi-agent.
Phase 6: monitoring and self-healing.
