# Android limits

Android controls are permissioned. A companion app cannot silently bypass the OS security model; sensitive actions require user-visible permissions or approved APIs.
