def summarize_placeholder(text: str) -> str:
    return text[:2000]

if __name__ == "__main__":
    print(summarize_placeholder("JARVIS web research helper"))
