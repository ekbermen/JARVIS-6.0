Python araçları için yer tutucu. Buraya medya, veri işleme ve bağımsız yardımcı komutlar eklenir.
