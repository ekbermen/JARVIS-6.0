from pathlib import Path

def list_files(root: str):
    return [str(p) for p in Path(root).rglob("*") if p.is_file()]
