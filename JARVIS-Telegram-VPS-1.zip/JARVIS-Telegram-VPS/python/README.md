# Python extension layer

Ana bot Node.js ile çalışır. Python burada şu tip ağır işler için ayrılmıştır:

- gelişmiş audio preprocessing
- offline test harness
- gelecekte yerel STT/TTS adapter'ı
- veri işleme

Python servisini zorunlu yapmadık; VPS üzerinde tek proses daha az hata yüzeyi oluşturur.
