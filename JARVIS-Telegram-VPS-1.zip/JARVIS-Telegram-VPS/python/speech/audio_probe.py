#!/usr/bin/env python3
import json
import sys
from pathlib import Path

def inspect(path: str) -> dict:
    p=Path(path)
    return {"exists":p.exists(),"name":p.name,"bytes":p.stat().st_size if p.exists() else 0,"suffix":p.suffix.lower()}

if __name__=="__main__":
    if len(sys.argv)<2:
        raise SystemExit("usage: audio_probe.py <file>")
    print(json.dumps(inspect(sys.argv[1]),ensure_ascii=False))
