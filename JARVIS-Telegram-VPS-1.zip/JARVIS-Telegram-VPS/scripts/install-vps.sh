#!/usr/bin/env bash
set -euo pipefail
sudo apt-get update
sudo apt-get install -y git curl nginx certbot python3-certbot-nginx build-essential cmake
if ! command -v node >/dev/null; then curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -; sudo apt-get install -y nodejs; fi
node --version
npm --version
echo "Node.js hazır. Repo'yu /opt/jarvis adresine yerleştirip npm install çalıştır."
