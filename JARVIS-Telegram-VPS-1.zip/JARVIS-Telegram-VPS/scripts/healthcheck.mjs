const port=process.env.PORT||8080;const r=await fetch(`http://127.0.0.1:${port}/health`);if(!r.ok)process.exit(1);console.log(await r.text());
