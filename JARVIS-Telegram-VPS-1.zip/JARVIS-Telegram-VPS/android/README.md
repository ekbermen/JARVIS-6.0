Android companion katmanı: Kotlin uygulaması; cihaz komutları sadece kullanıcı onayı ve Android izinleriyle yürütülür.
