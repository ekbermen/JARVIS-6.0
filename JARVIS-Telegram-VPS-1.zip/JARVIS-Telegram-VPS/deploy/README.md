VPS dağıtım varlıkları. GitHub Actions -> SSH/deploy -> Docker Compose veya systemd.
