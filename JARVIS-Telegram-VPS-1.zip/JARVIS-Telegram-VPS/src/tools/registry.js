export class ToolRegistry {
  constructor(){this.map=new Map();}
  register(tool){this.map.set(tool.name,tool);return this;}
  get(name){return this.map.get(name);}
  list(){return [...this.map.keys()];}
}
