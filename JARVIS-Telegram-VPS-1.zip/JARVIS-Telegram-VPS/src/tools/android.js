export function androidTool(){ return {name:"android", async execute(args){ return {ok:false, action:args?.action||"none", message:"Android companion required"}; }}; }
