export function githubTool(){ return {name:"github", async execute(args){ return {ok:false, action:args?.action||"none", message:"GitHub adapter placeholder"}; }}; }
