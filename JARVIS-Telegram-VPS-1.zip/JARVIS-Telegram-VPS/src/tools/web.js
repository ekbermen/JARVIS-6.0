export function webTool(fetchImpl=fetch){ return {name:"web_fetch", async execute({url}){ const r=await fetchImpl(url); return {status:r.status,text:(await r.text()).slice(0,20000)}; }}; }
