export function codeTool(){ return {name:"code", async execute({language,code}){ return {queued:true,language,bytes:Buffer.byteLength(code||"")}; }}; }
