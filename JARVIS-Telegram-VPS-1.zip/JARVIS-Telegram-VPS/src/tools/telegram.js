export function telegramTool(){ return {name:"telegram_send", async execute(args){ return {queued:true,args}; }}; }
