export function shellTool(){ return { name:"shell", async execute(){ throw new Error("Shell tool disabled until sandbox is configured"); } }; }
