export function schedulerTool(){ return {name:"schedule", async execute({when,task}){ return {scheduled:false,when,task,message:"Persistent scheduler adapter pending"}; }}; }
