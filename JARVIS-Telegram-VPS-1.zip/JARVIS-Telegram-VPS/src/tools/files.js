import fs from "node:fs/promises";
import path from "node:path";
export function createFileTool(root=process.cwd()){
 return {name:"file_write", async execute({file,content}){ const p=path.resolve(root,file); if(!p.startsWith(path.resolve(root))) throw new Error("path denied"); await fs.mkdir(path.dirname(p),{recursive:true}); await fs.writeFile(p,content,"utf8"); return {file:p,bytes:Buffer.byteLength(content)}; }};
}
