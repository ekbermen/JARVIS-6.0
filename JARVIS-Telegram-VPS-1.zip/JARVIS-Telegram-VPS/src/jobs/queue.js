export class JobQueue { constructor(){this.q=[];this.running=false;} push(job){this.q.push(job);return this.q.length;} size(){return this.q.length;} }
