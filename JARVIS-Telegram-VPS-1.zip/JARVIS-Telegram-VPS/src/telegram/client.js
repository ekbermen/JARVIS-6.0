import fs from 'node:fs/promises';
import FormData from 'form-data';
import {retry} from '../utils/retry.js';
export class TelegramClient{
  constructor(token,timeout=55000){this.token=token;this.base=`https://api.telegram.org/bot${token}`;this.fileBase=`https://api.telegram.org/file/bot${token}`;this.timeout=timeout}
  async call(method,body){return retry(async()=>{const r=await fetch(`${this.base}/${method}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(this.timeout)});const d=await r.json().catch(()=>({}));if(!r.ok||!d.ok)throw new Error(`Telegram ${method} ${r.status}: ${d.description||'unknown error'}`);return d.result},{retries:2})}
  getMe(){return this.call('getMe',{})}
  setWebhook(url,secret_token){return this.call('setWebhook',{url,...(secret_token?{secret_token}:{}),allowed_updates:['message']})}
  deleteWebhook(){return this.call('deleteWebhook',{})}
  getWebhookInfo(){return this.call('getWebhookInfo',{})}
  getFile(file_id){return this.call('getFile',{file_id})}
  async downloadFile(filePath){const r=await fetch(`${this.fileBase}/${filePath}`,{signal:AbortSignal.timeout(this.timeout)});if(!r.ok)throw new Error(`Telegram file download failed: ${r.status}`);return Buffer.from(await r.arrayBuffer())}
  async sendText(chat_id,text,extra={}){return this.call('sendMessage',{chat_id,text,...extra})}
  async sendVoice(chat_id,buffer,filename='jarvis.mp3',caption=''){const form=new FormData();form.append('chat_id',String(chat_id));form.append('voice',buffer,{filename,contentType:'audio/mpeg'});if(caption)form.append('caption',caption);const r=await fetch(`${this.base}/sendVoice`,{method:'POST',headers:form.getHeaders(),body:form,signal:AbortSignal.timeout(this.timeout)});const d=await r.json().catch(()=>({}));if(!r.ok||!d.ok)throw new Error(`Telegram sendVoice ${r.status}: ${d.description||'unknown error'}`);return d.result}
  async sendChatAction(chat_id,action){return this.call('sendChatAction',{chat_id,action})}
}
