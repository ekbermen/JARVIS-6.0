export class ApprovalGate {
  constructor(required=new Set()) { this.required=required; }
  needs(tool) { return this.required.has(tool); }
}
