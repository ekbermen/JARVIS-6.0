export class AgentOrchestrator {
  constructor({tools=[], memory, llm}) { this.tools=tools; this.memory=memory; this.llm=llm; }
  async run(input, context={}) {
    const plan=await this.llm.plan(input, context);
    const results=[];
    for (const step of (plan.steps||[]).slice(0,12)) {
      const tool=this.tools.find(t=>t.name===step.tool);
      if (!tool) continue;
      results.push(await tool.execute(step.args||{}, context));
    }
    return this.llm.finalize(input, results, context);
  }
}
