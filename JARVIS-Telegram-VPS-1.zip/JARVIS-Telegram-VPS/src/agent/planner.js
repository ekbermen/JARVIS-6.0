export function normalizePlan(plan) { return { steps:Array.isArray(plan?.steps)?plan.steps:[], goal:plan?.goal||"" }; }
