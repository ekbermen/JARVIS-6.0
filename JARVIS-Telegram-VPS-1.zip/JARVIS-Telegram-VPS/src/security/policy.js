export function policyFor(tool){ const approval=new Set(["shell","install_package","git_push","device_control"]); return {tool,requiresApproval:approval.has(tool)}; }
