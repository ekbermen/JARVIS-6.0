export class RuntimeState{
  constructor(){this.startedAt=Date.now();this.requests=0;this.lastError='';this.events=[];this.telegram='unknown';this.webhook='unknown'}
  hit(label='request'){this.requests++;this.event(`REQ ${label}`)}
  error(err){this.lastError=String(err?.message||err);this.event(`ERR ${this.lastError}`)}
  event(text){const line=`${new Date().toISOString()} ${text}`;this.events.push(line);if(this.events.length>100)this.events.shift()}
  snapshot({config,telegram,webhook,memoryMessages}){return {runtime:`up ${Math.floor((Date.now()-this.startedAt)/1000)}s`,model:config.chatModel,memory:{messages:memoryMessages},requests:this.requests,lastError:this.lastError,bot:telegram,webhook,publicUrl:config.publicBaseUrl,events:this.events}}
}
