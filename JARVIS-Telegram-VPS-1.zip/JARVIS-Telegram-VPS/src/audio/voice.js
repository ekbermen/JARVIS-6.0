export function detectVoice(update){const v=update?.message?.voice;if(!v)return null;return {fileId:v.file_id,mime:'audio/ogg',duration:Number(v.duration||0),size:Number(v.file_size||0)}}
export function validateVoice(v){if(!v)return false;if(v.size&&v.size>20*1024*1024)throw new Error('Ses dosyası Telegram bot indirme sınırını aşıyor.');return true}
