import process from 'node:process';
import dotenv from 'dotenv';
dotenv.config();
function required(name){const value=process.env[name];if(!value)throw new Error(`Missing environment variable: ${name}`);return value;}
function csv(value){return (value||'').split(',').map(v=>v.trim()).filter(Boolean)}
export function loadConfig(){
  const c={
    port:Number(process.env.PORT||8080),
    telegramToken:required('TELEGRAM_BOT_TOKEN'),
    allowedUserIds:csv(process.env.ALLOWED_TELEGRAM_USER_ID),
    allowedChatIds:csv(process.env.ALLOWED_TELEGRAM_CHAT_ID),
    xaiKey:required('XAI_API_KEY'),
    chatModel:process.env.XAI_CHAT_MODEL||'grok-4.6',
    sttModel:process.env.XAI_STT_MODEL||'grok-voice-1',
    ttsVoice:process.env.XAI_TTS_VOICE||'eve',
    ttsLanguage:process.env.XAI_TTS_LANGUAGE||'tr',
    jarvisName:process.env.JARVIS_NAME||'JARVIS',
    publicBaseUrl:process.env.PUBLIC_BASE_URL||'',
    logLevel:process.env.LOG_LEVEL||'info',
    maxHistory:Number(process.env.MAX_HISTORY_MESSAGES||20),
    requestTimeout:Number(process.env.REQUEST_TIMEOUT_MS||55000),
    webhookSecret:process.env.TELEGRAM_WEBHOOK_SECRET||'',
    adminToken:process.env.ADMIN_TOKEN||'',
    dataDir:process.env.DATA_DIR||'./data'
  };
  if(!c.allowedUserIds.length&&!c.allowedChatIds.length) console.warn('WARNING: no Telegram allowlist configured');
  return c;
}
