import {splitForTelegram} from './text.js';
export async function sendLongText(telegram,chatId,text){for(const chunk of splitForTelegram(text))await telegram.sendText(chatId,chunk)}
