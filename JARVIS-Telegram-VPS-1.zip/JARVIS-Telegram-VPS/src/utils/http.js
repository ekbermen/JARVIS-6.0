export function withTimeout(ms, upstream){const signal=AbortSignal.timeout(ms);return fetch(upstream,{...arguments[1],signal});}
export async function readJsonSafe(response){const text=await response.text();let data=null;try{data=JSON.parse(text)}catch{}return {text,data};}
export function is2xx(status){return status>=200&&status<300}
