const counters=new Map(); export function inc(name){ counters.set(name,(counters.get(name)||0)+1); } export function snapshot(){ return Object.fromEntries(counters); }
