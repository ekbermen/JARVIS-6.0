export function registerRoutes(app,{state}){ app.get("/api/status",(_req,res)=>res.json(state())); app.get("/api/tools",(_req,res)=>res.json({tools:[]})); }
