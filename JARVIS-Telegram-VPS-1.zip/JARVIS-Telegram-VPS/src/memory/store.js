import fs from 'node:fs/promises';import path from 'node:path';
export class MemoryStore{
  constructor(dir,maxMessages=20){this.file=path.join(dir,'conversations.json');this.maxMessages=maxMessages;this.data=new Map();this.ready=this.load()}
  async load(){try{const raw=await fs.readFile(this.file,'utf8');const obj=JSON.parse(raw);for(const [k,v] of Object.entries(obj))this.data.set(k,v)}catch{} }
  async save(){await fs.mkdir(path.dirname(this.file),{recursive:true});await fs.writeFile(this.file,JSON.stringify(Object.fromEntries(this.data)));}
  async get(chatId){await this.ready;return [...(this.data.get(String(chatId))||[])]}
  async push(chatId,message){await this.ready;const k=String(chatId);const arr=this.data.get(k)||[];arr.push({role:message.role,content:message.content,at:new Date().toISOString()});while(arr.length>this.maxMessages)arr.shift();this.data.set(k,arr);await this.save()}
  async clear(chatId){await this.ready;this.data.delete(String(chatId));await this.save()}
  async count(){await this.ready;let n=0;for(const a of this.data.values())n+=a.length;return n}
}
