export class SemanticMemory { constructor(store){this.store=store;} async recall(query){ return this.store?.recall?.(query)||[]; } async remember(item){ return this.store?.save?.(item); } }
