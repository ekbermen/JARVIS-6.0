import test from 'node:test';import assert from 'node:assert/strict';import {isAllowed} from '../src/security/allowlist.js';
test('allowlist user',()=>{const u={message:{from:{id:42},chat:{id:7}}};assert.equal(isAllowed(u,{allowedUserIds:['42'],allowedChatIds:[]}),true);assert.equal(isAllowed(u,{allowedUserIds:['99'],allowedChatIds:[]}),false)});
