import test from 'node:test';import assert from 'node:assert/strict';import {splitForTelegram,normalizeText} from '../src/utils/text.js';
test('normalizeText trims nulls',()=>assert.equal(normalizeText('  a\u0000\n'),'a'));
test('splitForTelegram limits chunks',()=>{const out=splitForTelegram('a'.repeat(8000),3800);assert.ok(out.length>=3);assert.ok(out.every(x=>x.length<=3800))});
