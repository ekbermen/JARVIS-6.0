Docker imajları servisleri ayrı çalıştırmak için tutulur.
